package dbdriver

import (
	"database/sql"
	"encoding/json"
	"fmt"
	_ "github.com/mattn/go-sqlite3"
	"strconv"
	"strings"
	"time"
)

func GetGutenLibDB() string {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	fmt.Println("connects to db")
	checkErr(err)
	//Get Guten Lib
	rows, err := db.Query("select * from books order by bookid asc;")
	checkErr(err)
	var bookid int
	var title string
	var author string
	var subject string
	var viewlink string
	var books string = `{"list":[`

	for rows.Next() {
		err = rows.Scan(&bookid, &title, &author, &subject, &viewlink)
		checkErr(err)
		currBook := &Book{Bookid: bookid, Title: title, Author: author, Subject: subject, Viewlink: viewlink}
		res2B, _ := json.Marshal(currBook)
		books += string(res2B) + ","
	}
	index := strings.LastIndex(books, `,`)
	books2 := books[0:index]
	books2 += `]}`

	rows.Close()
	db.Close()
	return books2
}

func GetUserLibDB(userid int) string {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)

	//Get User Lib
	stmt, err := db.Prepare("select bookid,lastread from userbooks where userid==? order by bookid asc;")
	checkErr(err)
	rows, err := stmt.Query(userid)
	//checkErr(err)

	if err == nil {
		var bookid int
		var lastread string
		var books string = `{"list":[`

		for rows.Next() {
			err = rows.Scan(&bookid, &lastread)
			checkErr(err)
			currBook := &UserBook{Bookid: bookid, LastRead: lastread}
			res2B, _ := json.Marshal(currBook)
			books += string(res2B) + ","
		}
		//fmt.Println(books)
		index := strings.LastIndex(books, `,`)
		books2 := books[0:index]
		//fmt.Println(books2)
		books2 += `]}`

		rows.Close()
		db.Close()
		return books2
	} else {
		return ""
	}
}

func AddToUserBooksDB(userid int, bookid int) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)
	lastread := time.Now()
	//Add Book to UserLib
	db.Exec("PRAGMA foreign_keys = ON", nil)
	checkErr(err)

	stmt, err := db.Prepare("INSERT INTO userbooks(userid,bookid,lastread) values(?,?,?);")
	checkErr(err)
	res, err := stmt.Exec(userid, bookid, lastread)
	//checkErr(err)
	if err != nil {
		db.Close()
		return false
	} else {
		fmt.Println(res.LastInsertId())
		db.Close()
		return true
	}

}

func ValidateUserDB(username string) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)

	//look for user
	stmt, err := db.Prepare("select * from users where username==?")
	checkErr(err)
	rows, _ := stmt.Query(username)

	checkErr(err)
	return (rows.Next())
}

func ValidateLoginDB(username string, pwd string) (bool, string) {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)

	//look for user pwd combo
	stmt, err := db.Prepare("select userid from users where username==? and pwd==?")
	checkErr(err)

	rows, _ := stmt.Query(username, pwd)

	if rows.Next() {
		var userid int
		err := rows.Scan(&userid)
		checkErr(err)
		id := strconv.Itoa(userid)
		db.Close()
		rows.Close()
		return true, id
	} else {
		rows.Close()
		db.Close()
		return false, "-1"
	}

}

func AddUserDB(username string, pwd string) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)
	//Add User attempt
	stmt, err := db.Prepare("INSERT INTO users(username,pwd) values(?,?)")
	checkErr(err)
	res, err := stmt.Exec(username, pwd)

	if err != nil || res == nil {
		db.Close()
		return false
	} else {
		fmt.Println(res.LastInsertId())
		db.Close()
		return true
	}

}

func DeleteUserDB(username string, pwd string) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)
	db.Exec("PRAGMA foreign_keys = ON", nil)
	checkErr(err)
	//Delete User
	stmt, err := db.Prepare("DELETE FROM users where username=? and pwd=?;")
	checkErr(err)
	res, err := stmt.Exec(username, pwd)
	rows, _ := res.RowsAffected()
	if err != nil || rows == 0 {
		db.Close()
		return false
	} else {
		fmt.Println(res.RowsAffected())
		db.Close()
		return true
	}

}

func UpdateLastReadDB(userid int, bookid int) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)
	stmt, err := db.Prepare("UPDATE userbooks SET lastread=? where userid==? and bookid==?")
	checkErr(err)
	res, err := stmt.Exec(time.Now(), userid, bookid)
	//return (res.RowsAffected())
	rows, _ := res.RowsAffected()
	return (rows > 0)
}

func ChangePasswordDB(userid int, oldpwd string, newpwd string) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)
	//look for user pwd combo
	stmt, err := db.Prepare("select * from users where userid==? and pwd==?")
	checkErr(err)
	rows, _ := stmt.Query(userid, oldpwd)

	if rows.Next() {
		fmt.Println("Query 1 good")
		stmt2, err := db.Prepare("UPDATE users SET pwd=? where userid=? ;")
		checkErr(err)

		res, err := stmt2.Exec(newpwd, userid)

		if err == nil {
			fmt.Println(res.RowsAffected())
			db.Close()
			return true
		} else {
			db.Close()
			return false
		}

	} else {
		db.Close()
		return false
	}
}

func DeleteFromUserLibDB(userid int, bookid int) bool {
	db, err := sql.Open("sqlite3", "./GutenLib.db")
	checkErr(err)
	db.Exec("PRAGMA foreign_keys = ON", nil)
	checkErr(err)
	//Delete Book from UserLib
	stmt, err := db.Prepare("DELETE FROM userbooks where userid==? and bookid==?")
	checkErr(err)
	res, err := stmt.Exec(userid, bookid)
	checkErr(err)
	rows, _ := res.RowsAffected()
	if err != nil || rows == 0 {
		db.Close()
		return false
	} else {
		fmt.Println(res.RowsAffected())
		db.Close()
		return true
	}

}

type Book struct {
	Bookid   int    `json:"bookid"`
	Title    string `json:"title"`
	Author   string `json:"author"`
	Subject  string `json:"subject"`
	Viewlink string `json:"viewlink"`
}

type UserBook struct {
	Bookid   int    `json:"bookid"`
	LastRead string `json:"lastread"`
}

func checkErr(err error) {
	if err != nil {
		panic(err)
	}
}
